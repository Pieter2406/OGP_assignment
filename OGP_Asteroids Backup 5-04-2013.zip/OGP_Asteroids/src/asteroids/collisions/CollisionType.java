package asteroids.collisions;

public interface CollisionType {
	public void collide();
}
