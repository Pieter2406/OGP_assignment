package asteroids.collisions;

import asteroids.studentdefined.Asteroid;

public class AsteroidAsteroidCollision implements CollisionType {

	public AsteroidAsteroidCollision(Asteroid o1, Asteroid o2) {
		// TODO Auto-generated constructor stub
	}

}
