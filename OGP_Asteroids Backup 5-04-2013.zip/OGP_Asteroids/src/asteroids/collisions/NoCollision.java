package asteroids.collisions;

public class NoCollision implements CollisionType {

	public NoCollision() {
		// TODO Auto-generated constructor stub
	}

}
