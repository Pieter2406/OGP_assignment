package asteroids.collisions;

import asteroids.studentdefined.Ship;

public class ShipShipCollision implements CollisionType {

	public ShipShipCollision(Ship o1, Ship o2) {
		// TODO Auto-generated constructor stub
	}

}
