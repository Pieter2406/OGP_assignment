package asteroids.collisions;

import asteroids.studentdefined.Asteroid;
import asteroids.studentdefined.Ship;

public class AsteroidShipCollision implements CollisionType {

	public AsteroidShipCollision(Asteroid o1, Ship o2) {
		// TODO Auto-generated constructor stub
	}

}
